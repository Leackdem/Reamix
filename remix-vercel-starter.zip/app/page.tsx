"use client";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Member = { id: string; email?: string; user_metadata?: { full_name?: string } };
type Task = { id: string; title: string; description: string; points: number };
const TASKS: Task[] = [
  { id: "explore", title: "Explore your dashboard", description: "Review the member workspace.", points: 10 },
  { id: "learn", title: "Read the safety guide", description: "Learn why demo balances are not real money.", points: 15 },
  { id: "profile", title: "Review your profile", description: "Check your account and activation status.", points: 5 }
];
export default function Home() {
  const [supabase, setSupabase] = useState<ReturnType<typeof createClient> | null>(null);
  const [user, setUser] = useState<Member | null>(null);
  const [view, setView] = useState("dashboard");
  const [mode, setMode] = useState<"signup"|"login">("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [status, setStatus] = useState("Not activated");
  const [points, setPoints] = useState(0);
  const [completed, setCompleted] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    try {
      const client = createClient(); setSupabase(client);
      client.auth.getUser().then(({data}) => { if (data.user) { setUser(data.user as Member); loadMember(client, data.user.id); } });
      const { data: listener } = client.auth.onAuthStateChange((_event, session) => {
        const u = session?.user as Member | undefined; setUser(u ?? null);
        if (u) loadMember(client, u.id);
      });
      return () => listener.subscription.unsubscribe();
    } catch (e) { setError(e instanceof Error ? e.message : "Configuration missing."); }
  }, []);
  async function loadMember(client: ReturnType<typeof createClient>, id: string) {
    const {data} = await client.from("profiles").select("activation_status,points").eq("id", id).maybeSingle();
    if (data) { setStatus(data.activation_status); setPoints(data.points ?? 0); }
    const {data: rows} = await client.from("task_completions").select("task_id").eq("user_id", id);
    if (rows) setCompleted(rows.map((r: {task_id:string}) => r.task_id));
  }
  async function auth(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return; setError(""); setMessage(""); setLoading(true);
    try {
      if (mode === "signup") {
        const {data, error} = await supabase.auth.signUp({email,password,options:{data:{full_name:name}}});
        if (error) throw error;
        if (data.user && !data.session) setMessage("Check your email to confirm your account, then sign in.");
        else setMessage("Account created. Your activation status is pending.");
      } else {
        const {error} = await supabase.auth.signInWithPassword({email,password}); if (error) throw error;
        setMessage("Signed in successfully.");
      }
    } catch(e) { setError(e instanceof Error ? e.message : "Authentication failed."); }
    finally { setLoading(false); }
  }
  async function completeTask(task: Task) {
    if (!supabase || !user) return;
    setError(""); setMessage("");
    const {error} = await supabase.rpc("complete_remix_task", {p_task_id:task.id});
    if (error) { setError(error.message); return; }
    setMessage("Task recorded. Demo points are not cash or withdrawable earnings.");
    await loadMember(supabase,user.id);
  }
  async function activate() {
    setError(""); setMessage(""); setLoading(true);
    try {
      const {data: {session}} = await supabase!.auth.getSession();
      if (!session) throw new Error("Please sign in first.");
      const response = await fetch("/api/mpesa/stk", {method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${session.access_token}`},body:JSON.stringify({phone:email /* replace with dedicated phone field in production */})});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not start payment.");
      setMessage("Payment prompt requested. Complete it on your phone, then wait for the verified callback. Checkout request: "+data.checkoutRequestId);
    } catch(e) { setError(e instanceof Error ? e.message : "Payment request failed."); }
    finally { setLoading(false); }
  }
  async function signOut() { await supabase?.auth.signOut(); setUser(null); setView("dashboard"); setMessage("Signed out."); }
  const nav = [["dashboard","Dashboard"],["tasks","Tasks"],["activation","Activate account"],["profile","Profile"]];
  return <main className="wrap">
    <header className="top"><div className="brand"><div className="logo">R</div><div>remix<span style={{color:"#a78bfa"}}>.</span><div className="muted" style={{fontWeight:400}}>Member hub</div></div></div><div>{user ? <><span className="pill">SIGNED IN</span> <button className="secondary" onClick={signOut}>Sign out</button></> : <span className="pill">MEMBER PORTAL</span>}</div></header>
    {!user ? <div style={{maxWidth:540,margin:"25px auto"}} className="panel">
      <h1 className="section-title">{mode==="signup"?"Create your account":"Welcome back"}</h1>
      <p className="muted">Register to access the Remix member dashboard. Account activation is separate and must be verified.</p>
      <div style={{display:"flex",gap:8,margin:"18px 0"}}><button className={mode==="signup"?"btn":"secondary"} onClick={()=>setMode("signup")}>Register</button><button className={mode==="login"?"btn":"secondary"} onClick={()=>setMode("login")}>Sign in</button></div>
      <form onSubmit={auth}>{mode==="signup"&&<><label className="muted">Full name</label><input className="field" value={name} onChange={e=>setName(e.target.value)} required autoComplete="name"/></>}
      <label className="muted">Email</label><input className="field" type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email"/>
      <label className="muted">Password (minimum 8 characters)</label><input className="field" type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required autoComplete={mode==="signup"?"new-password":"current-password"}/>
      <button className="btn" disabled={loading}>{loading?"Please wait…":mode==="signup"?"Create account":"Sign in"}</button></form>
      <p className="muted" style={{lineHeight:1.6,marginTop:16}}>Never reuse a password. Use email confirmation and secure authentication settings before opening registration publicly.</p>
    </div> : <div className="grid">
      <aside className="panel side">{nav.map(([id,label])=><button key={id} className={view===id?"active":""} onClick={()=>setView(id)}>{label}</button>)}<div className="muted" style={{marginTop:20}}>Status: {status}</div></aside>
      <section className="panel">
        {view==="dashboard"&&<><h1 className="section-title">Your dashboard</h1><div className="notice">Remix does not promise earnings. Task points are demo points, not cash, and the platform does not provide live trading.</div><div className="stats" style={{marginTop:16}}><div className="panel"><div className="muted">Demo points</div><div className="stat">{points}</div></div><div className="panel"><div className="muted">Tasks completed</div><div className="stat">{completed.length}/{TASKS.length}</div></div><div className="panel"><div className="muted">Account activation</div><div className="stat" style={{fontSize:18}}>{status}</div></div></div><h2>Quick actions</h2><button className="btn" onClick={()=>setView("tasks")}>Explore tasks</button> <button className="secondary" onClick={()=>setView("activation")}>Activate account</button></>}
        {view==="tasks"&&<><h1 className="section-title">Member tasks</h1><p className="muted">Complete sample learning tasks. Points have no cash value.</p>{TASKS.map(t=><div className="row task" key={t.id}><div><b>{t.title}</b><p className="muted">{t.description} · {t.points} demo points</p></div><button className="secondary" disabled={completed.includes(t.id)} onClick={()=>completeTask(t)}>{completed.includes(t.id)?"Completed":"Complete"}</button></div>)}</>}
        {view==="activation"&&<><h1 className="section-title">Activate your account</h1><div className="notice">Activation fee: KSh 50. The final checkout recipient and fee purpose must be clearly disclosed before payment. Do not pay a number unless you have independently confirmed it belongs to the business.</div><p className="muted" style={{lineHeight:1.7}}>This starter uses Safaricom Daraja STK Push and a server-side callback to record successful payments. Add a dedicated Safaricom phone-number field and verify your business shortcode before production. Never mark an account active based only on a screenshot or user-entered reference.</p><button className="btn" disabled title="Finish phone-number input and configure Daraja credentials first">Set up M-Pesa checkout</button><p className="muted">Payment initiation is intentionally disabled until the phone field and Daraja environment are configured. See README for the exact steps.</p></>}
        {view==="profile"&&<><h1 className="section-title">My profile</h1><div className="row"><span className="muted">Email</span><b>{user.email}</b></div><div className="row"><span className="muted">Activation</span><b>{status}</b></div><div className="row"><span className="muted">Demo points</span><b>{points}</b></div></>}
        {message&&<p className="success" role="status">{message}</p>}{error&&<p className="error" role="alert">{error}</p>}
      </section>
    </div>}
    <nav className="mobile-nav">{nav.map(([id,label])=><button key={id} onClick={()=>setView(id)}>{label}</button>)}</nav>
    <footer className="muted" style={{textAlign:"center",padding:"24px 0"}}>Remix · Secure account and payment verification starter</footer>
  </main>;
}