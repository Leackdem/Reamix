import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Remix — Member Hub",
  description: "Remix member dashboard, tasks and account activation.",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}