import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
function env(name: string) { const v = process.env[name]; if (!v) throw new Error(`Missing server configuration: ${name}`); return v; }
function timestamp() { const d = new Date(); return d.getFullYear().toString()+String(d.getMonth()+1).padStart(2,"0")+String(d.getDate()).padStart(2,"0")+String(d.getHours()).padStart(2,"0")+String(d.getMinutes()).padStart(2,"0")+String(d.getSeconds()).padStart(2,"0"); }
function toKenyanPhone(input: string) { const digits=input.replace(/\D/g,""); if (/^2547\d{8}$/.test(digits)||/^2541\d{8}$/.test(digits)) return digits; if (/^0[17]\d{8}$/.test(digits)) return "254"+digits.slice(1); if (/^[17]\d{8}$/.test(digits)) return "254"+digits; throw new Error("Enter a valid Kenyan mobile number."); }
export async function POST(req: NextRequest) {
  try {
    const auth = req.headers.get("authorization") || "";
    if (!auth.startsWith("Bearer ")) return NextResponse.json({error:"Sign in required."},{status:401});
    const supabase = createClient(env("NEXT_PUBLIC_SUPABASE_URL"),env("SUPABASE_SERVICE_ROLE_KEY"),{auth:{persistSession:false}});
    const {data:{user},error:authError}=await supabase.auth.getUser(auth.slice(7));
    if(authError||!user) return NextResponse.json({error:"Invalid session."},{status:401});
    const body=await req.json();
    const phone=toKenyanPhone(String(body.phone||""));
    const amount=Number(process.env.ACTIVATION_AMOUNT_KES||"50");
    if(!Number.isInteger(amount)||amount<1) throw new Error("Invalid activation amount configuration.");
    const base=process.env.DARAJA_ENV==="production"?"https://api.safaricom.co.ke":"https://sandbox.safaricom.co.ke";
    const key=env("DARAJA_CONSUMER_KEY"), secret=env("DARAJA_CONSUMER_SECRET");
    const tokenRes=await fetch(base+"/oauth/v1/generate?grant_type=client_credentials",{headers:{Authorization:"Basic "+Buffer.from(key+":"+secret).toString("base64")},cache:"no-store"});
    const tokenData=await tokenRes.json(); if(!tokenRes.ok||!tokenData.access_token) return NextResponse.json({error:"Daraja authentication failed. Check credentials and environment."},{status:502});
    const shortcode=env("DARAJA_SHORTCODE"), passkey=env("DARAJA_PASSKEY"), time=timestamp();
    const password=Buffer.from(shortcode+passkey+time).toString("base64");
    const callback=env("DARAJA_CALLBACK_URL");
    if(!callback.startsWith("https://")) throw new Error("DARAJA_CALLBACK_URL must be a public HTTPS URL.");
    const payload={BusinessShortCode:shortcode,Password:password,Timestamp:time,TransactionType:"CustomerPayBillOnline",Amount:amount,PartyA:phone,PartyB:shortcode,PhoneNumber:phone,CallBackURL:callback,AccountReference:"REMIX-"+user.id.slice(0,8),TransactionDesc:"Remix account activation"};
    const stkRes=await fetch(base+"/mpesa/stkpush/v1/processrequest",{method:"POST",headers:{Authorization:"Bearer "+tokenData.access_token,"Content-Type":"application/json"},body:JSON.stringify(payload),cache:"no-store"});
    const stk=await stkRes.json();
    if(!stkRes.ok||!stk.CheckoutRequestID) return NextResponse.json({error:stk.errorMessage||stk.ResponseDescription||"Daraja did not accept the payment request."},{status:502});
    const {error:insertError}=await supabase.from("payments").insert({user_id:user.id,amount_kes:amount,phone,checkout_request_id:stk.CheckoutRequestID,merchant_request_id:stk.MerchantRequestID,status:"pending"});
    if(insertError) return NextResponse.json({error:"Payment request was started but could not be recorded. Contact support before retrying."},{status:500});
    return NextResponse.json({ok:true,checkoutRequestId:stk.CheckoutRequestID,message:"Check your phone to approve the M-Pesa prompt."});
  } catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Unexpected payment error."},{status:400}); }
}