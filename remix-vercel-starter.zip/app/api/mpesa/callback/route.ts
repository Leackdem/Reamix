import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const callback = body?.Body?.stkCallback;
    if (!callback?.CheckoutRequestID || !callback?.ResultCode) return NextResponse.json({ResultCode:1,ResultDesc:"Invalid callback payload"});
    const admin = createAdminClient();
    const checkoutId = String(callback.CheckoutRequestID);
    const success = Number(callback.ResultCode) === 0;
    const items = callback.CallbackMetadata?.Item ?? [];
    const field = (name: string) => items.find((x: {Name:string;Value?:unknown})=>x.Name===name)?.Value;
    const receipt = success ? String(field("MpesaReceiptNumber") ?? "") : null;
    const amount = success ? Number(field("Amount")) : null;
    const phone = success ? String(field("PhoneNumber") ?? "") : null;
    // Only update a pre-existing payment row. Never activate based on client-supplied claims.
    const {data: payment,error:lookupError} = await admin.from("payments").select("id,user_id,amount_kes,status").eq("checkout_request_id",checkoutId).maybeSingle();
    if (lookupError || !payment) return NextResponse.json({ResultCode:1,ResultDesc:"Payment request not found"});
    if (payment.status !== "pending") return NextResponse.json({ResultCode:0,ResultDesc:"Already processed"});
    if (!success) {
      await admin.from("payments").update({status:"failed",result_code:Number(callback.ResultCode),result_description:String(callback.ResultDesc||"Payment failed")}).eq("id",payment.id);
      return NextResponse.json({ResultCode:0,ResultDesc:"Failure recorded"});
    }
    if (!receipt || amount !== Number(payment.amount_kes) || !phone) {
      await admin.from("payments").update({status:"review",result_code:0,result_description:"Callback metadata mismatch; manual review required"}).eq("id",payment.id);
      return NextResponse.json({ResultCode:0,ResultDesc:"Payment flagged for review"});
    }
    const {error:updateError}=await admin.from("payments").update({status:"paid",mpesa_receipt:receipt,paid_amount_kes:amount,paid_phone:phone,result_code:0,result_description:"Payment confirmed by Daraja callback"}).eq("id",payment.id).eq("status","pending");
    if(updateError) return NextResponse.json({ResultCode:1,ResultDesc:"Could not record payment"});
    const {error:profileError}=await admin.from("profiles").update({activation_status:"active"}).eq("id",payment.user_id);
    if(profileError) {
      await admin.from("payments").update({status:"review",result_description:"Payment received; profile activation update failed"}).eq("id",payment.id);
      return NextResponse.json({ResultCode:1,ResultDesc:"Activation requires reconciliation"});
    }
    return NextResponse.json({ResultCode:0,ResultDesc:"Payment verified and account activated"});
  } catch {
    return NextResponse.json({ResultCode:1,ResultDesc:"Callback processing error"});
  }
}