# Remix — Vercel + Supabase starter

This is a deployable starter for member registration, dashboard, sample tasks, and a Safaricom Daraja STK Push payment-verification flow. It is **not production-ready until configuration, phone input, payment testing, and a security review are complete**.

## Important safeguards

- Do not promise guaranteed earnings or imply task points are cash.
- KSh 50 activation is configured by `ACTIVATION_AMOUNT_KES`; disclose fee purpose, terms and refunds before asking members to pay.
- Only integrate a Safaricom shortcode and business account you are authorized to use. Do not hard-code a personal recipient phone number into a production payment flow.
- Callback endpoints must be public HTTPS. Callback requests should be validated/reconciled with Daraja transaction records before going live; add IP/network controls and reconciliation monitoring where supported.
- Do not collect or store users' M-Pesa PINs. Users approve prompts on their own phones.
- The current UI intentionally disables payment initiation until a dedicated phone-number field is wired and the Daraja setup is verified.
- For a real production service, add rate limiting, abuse controls, audit logs, support contacts, terms/privacy/refund pages, and independent security review.

## Stack

- Next.js App Router
- Supabase Auth + Postgres + Row Level Security
- Safaricom Daraja STK Push (server route) and callback (server route)
- Vercel hosting

## 1. Create Supabase project

1. Create a project at https://supabase.com/.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. In **Authentication → URL Configuration**, set your site URL after deployment and add the Vercel preview/production URLs to allowed redirects.
4. For registration, choose whether email confirmation is required. Keep it enabled for public production sign-ups.

Copy the Project URL and anon/publishable key from Supabase project API settings. Copy the service-role key only to server environment variables; never expose it in `NEXT_PUBLIC_*`.

## 2. Create Daraja app

1. Use https://developer.safaricom.co.ke/ and start in sandbox.
2. Obtain authorized consumer key/secret and configure the supported shortcode/passkey for STK Push.
3. The callback URL should be `https://YOUR-DEPLOYMENT-DOMAIN/api/mpesa/callback`.
4. Add a dedicated phone-number field to the activation page before enabling the button. The starter currently disables checkout intentionally rather than guessing a phone number from email.
5. Test successful, cancelled, timed-out, duplicate, and mismatched callbacks in sandbox. Reconcile payments before switching to production.

## 3. Add environment variables

Copy `.env.example` values into your local `.env.local` and Vercel Project → Settings → Environment Variables. Set values separately for Preview and Production as appropriate.

Required names:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` (server-only)
- `DARAJA_ENV` (`sandbox` until approved for production)
- `DARAJA_CONSUMER_KEY`
- `DARAJA_CONSUMER_SECRET`
- `DARAJA_SHORTCODE`
- `DARAJA_PASSKEY`
- `DARAJA_CALLBACK_URL`
- `ACTIVATION_AMOUNT_KES` (`50` if that is the disclosed fee)

Never commit `.env.local` or real credentials to Git.

## 4. Publish on Vercel

1. Upload this project to a private GitHub repository (see below).
2. In https://vercel.com/new, import that repository.
3. Framework should be detected as Next.js. Use default build command `next build`.
4. Add the environment variables in Project Settings.
5. Deploy. Copy the `*.vercel.app` URL.
6. Set `DARAJA_CALLBACK_URL` to the deployed HTTPS callback URL, redeploy, and test end-to-end in Daraja sandbox.

## 5. Upload from a computer or phone

- Download and extract the ZIP.
- Create a repository at https://github.com/new.
- Upload the extracted files using GitHub's web UI (Add file → Upload files), then commit.
- Import the repo in Vercel.

## 6. Before production

- Add phone input and wire the payment button to `/api/mpesa/stk` (send a Kenyan phone number, not an email).
- Review Daraja callback authenticity and transaction status using current Safaricom guidance. A public callback URL alone is not proof of authenticity.
- Add payment reconciliation, idempotency, rate limits, and monitoring.
- Ensure activation can only follow a verified, matching payment and that refunds/disputes can be handled.
- Add clear terms, privacy notice, contact details and refund policy.
- Do not launch any spin/prize mechanic as real-money gambling without obtaining appropriate legal advice and approvals.
- Test auth, RLS, task double-submit protection, payment failures, and webhook retries.

## Local development

```bash
npm install
cp .env.example .env.local
npm run dev
```

Local development needs Supabase env values. Payment checkout will not work until Daraja variables are configured. Never paste secrets into chat.
