-- Run in Supabase SQL Editor. Review before production.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  activation_status text not null default 'pending' check (activation_status in ('pending','active','review')),
  points integer not null default 0 check (points >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.task_completions (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id text not null check (task_id in ('explore','learn','profile')),
  points integer not null check (points >= 0),
  completed_at timestamptz not null default now(),
  unique(user_id, task_id)
);
create table if not exists public.payments (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_kes integer not null check (amount_kes > 0),
  phone text not null,
  checkout_request_id text unique not null,
  merchant_request_id text,
  status text not null default 'pending' check (status in ('pending','paid','failed','review')),
  mpesa_receipt text,
  paid_amount_kes numeric,
  paid_phone text,
  result_code integer,
  result_description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists payments_user_id_idx on public.payments(user_id);
alter table public.profiles enable row level security;
alter table public.task_completions enable row level security;
alter table public.payments enable row level security;

-- Profiles: member can read their own profile. Creation is handled by trusted trigger.
create policy "profiles select own" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "task completions select own" on public.task_completions for select to authenticated using (auth.uid() = user_id);
create policy "payments select own" on public.payments for select to authenticated using (auth.uid() = user_id);
-- No client write policies for payments or activation status: server callback owns those updates.

create or replace function public.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name) values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_remix on auth.users;
create trigger on_auth_user_created_remix after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create or replace function public.complete_remix_task(p_task_id text)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare reward integer;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  reward := case p_task_id when 'explore' then 10 when 'learn' then 15 when 'profile' then 5 else null end;
  if reward is null then raise exception 'Unknown task'; end if;
  insert into public.task_completions(user_id, task_id, points)
  values(auth.uid(), p_task_id, reward);
  update public.profiles set points = points + reward where id = auth.uid();
  return jsonb_build_object('ok', true, 'points', reward);
exception when unique_violation then
  raise exception 'Task already completed';
end;
$$;
revoke all on function public.complete_remix_task(text) from public;
grant execute on function public.complete_remix_task(text) to authenticated;
grant select on public.profiles to authenticated;
grant select on public.task_completions to authenticated;
grant select on public.payments to authenticated;
